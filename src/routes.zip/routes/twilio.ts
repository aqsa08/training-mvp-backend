import { Router } from "express";
import { pool } from "../db/pool";

const router = Router();

// Twilio sends application/x-www-form-urlencoded
// Make sure app.ts has: app.use(express.urlencoded({ extended: false }));
router.post("/inbound", async (req, res) => {
  const fromRaw = String(req.body.From || "");
  const bodyRaw = String(req.body.Body || "");

  // Normalize phone number (handle whatsapp: prefix)
  const fromPhone = fromRaw.startsWith("whatsapp:")
    ? fromRaw.replace("whatsapp:", "")
    : fromRaw;

  const reflectionText = bodyRaw.trim();

  if (!fromPhone || !reflectionText) {
    // Always respond with valid TwiML so Twilio is happy
    res.type("text/xml").send("<Response></Response>");
    return;
  }

  const client = await pool.connect();

  try {
    // 1) Find user by phone_number
    const userRes = await client.query(
      `
      SELECT id
      FROM users
      WHERE phone_number = $1
      LIMIT 1
      `,
      [fromPhone]
    );

    if (userRes.rowCount === 0) {
      // Unknown sender, ignore politely
      res.type("text/xml").send("<Response></Response>");
      return;
    }

    const userId: number = userRes.rows[0].id;

    // 2) Find MOST RECENT sent message for this user
    const sentRes = await client.query(
      `
      SELECT sm.id        AS sent_message_id,
             sm.cohort_user_id,
             sm.lesson_id
      FROM sent_messages sm
      JOIN cohort_users cu ON cu.id = sm.cohort_user_id
      WHERE cu.user_id = $1
      ORDER BY sm.sent_at DESC
      LIMIT 1
      `,
      [userId]
    );

    if (sentRes.rowCount === 0) {
      // We've never sent them a lesson (or logs missing) → nothing to attach reflection to
      res.type("text/xml").send("<Response></Response>");
      return;
    }

    const sent = sentRes.rows[0] as {
      sent_message_id: number;
      cohort_user_id: number;
      lesson_id: number;
    };

    // 3) Insert reflection
    // If you later want ONLY one reflection per lesson, you can:
    // - add UNIQUE (cohort_user_id, lesson_id) on reflections
    // - use INSERT ... ON CONFLICT DO UPDATE
    await client.query(
      `
      INSERT INTO reflections (cohort_user_id, lesson_id, response_text)
      VALUES ($1, $2, $3)
      `,
      [sent.cohort_user_id, sent.lesson_id, reflectionText]
    );

    // 4) Return TwiML acknowledgement
    const twiml =
      "<Response>" +
      "<Message>Thanks for your reflection. Keep going – one day at a time.</Message>" +
      "</Response>";

    res.type("text/xml").send(twiml);
  } catch (err) {
    console.error("Error in /twilio/inbound:", err);
    // Still respond with a valid empty TwiML to avoid Twilio retry storms
    res.type("text/xml").status(200).send("<Response></Response>");
  } finally {
    client.release();
  }
});

export default router;
